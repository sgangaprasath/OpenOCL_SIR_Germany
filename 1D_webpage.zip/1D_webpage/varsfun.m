function varsfun(svh)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function to define variables for OpenOCL %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global Np
global Icus
global uM
global Py

svh.addState('S1','lb', 0); % Susceptible population
svh.addState('I1','lb', 0, 'ub', Icus*Np/Py); % Infected population with upper-bound from ICU capacity
svh.addState('R1','lb', 0); % Recovered population

% Scalar u: 0 <= F <= uub
svh.addControl('F', 'lb', 0, 'ub', uM); % Controller with upper bound
svh.addParameter('Beta');
svh.addParameter('Gamma');
svh.addParameter('Py');
svh.addParameter('uM');
svh.addParameter('Icus');
svh.addState('Time');

svh.addParameter('Np');
svh.addParameter('AlpL');
svh.addParameter('AlpE');
svh.addParameter('AlpS');
svh.addParameter('Disc');
end