function daefun(daeh,x,~,u,p)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SIR closed-loop dynamics ODEs %
% Ref: Eqn.1 in arXiv:XXXX.XXXX %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
conf = daeh.userdata; % Structure with country specific parameters
cc = conf.cc;
co = conf.co;

c = co - u.F.*cc; % Closed-loop Control matrix

lam = (p.Beta).*c*x.I1;

% SIR equation RHS expressions
sRHS = -lam.*x.S1;
iRHS = -sRHS - (p.Gamma)*x.I1;
rRHS = (p.Gamma)*x.I1;

daeh.setODE('S1', sRHS); % Evolution of Susceptible population
daeh.setODE('I1', iRHS); % Evolution of Infected population
daeh.setODE('R1', rRHS); % Evolution of Recovered population
daeh.setODE('Time', 1);
end