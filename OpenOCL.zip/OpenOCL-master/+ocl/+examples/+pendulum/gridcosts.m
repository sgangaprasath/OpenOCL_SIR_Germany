function gridcosts(ch,k,K,x,~)
if k==K
  ch.add(x.time);
end


