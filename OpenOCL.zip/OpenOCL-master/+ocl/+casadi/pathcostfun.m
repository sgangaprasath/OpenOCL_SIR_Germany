function c = pathcostfun(casadi_fun,x,z,u,p)
c = casadi_fun(x,z,u,p);