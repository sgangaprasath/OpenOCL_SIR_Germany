The main package folder +ocl contains the public API that is seen by the user. 
Function in the subfolders (subpackages) are usually not see by the users of OpenOCL 
with the exception of the examples.