function solve(acados_ocp)

% solve
acados_ocp.solve();