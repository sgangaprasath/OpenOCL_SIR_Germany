function r = times(tau_root, h)
r = tau_root(2:end) * h;