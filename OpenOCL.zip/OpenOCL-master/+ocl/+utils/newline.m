function r = newline()
  r = char(10);

