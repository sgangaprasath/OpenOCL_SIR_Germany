function argError(arg)
ocl.utils.error(['Wrong value for argument ', arg, ' given. Please check the docs at ', ocl.utils.docMessage()]);
end

