function debug(msg)
disp(msg);
