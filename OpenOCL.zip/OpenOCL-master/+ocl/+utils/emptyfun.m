function r = emptyfun(varargin)
r = [];