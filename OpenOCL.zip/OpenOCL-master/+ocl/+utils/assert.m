function assert(condition, varargin)
  assert(condition,varargin{:});
end