function r = fieldnamesContain(names, id)
  r = any(strcmp(names,id));
end