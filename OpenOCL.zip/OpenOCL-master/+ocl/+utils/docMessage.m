function s = docMessage()
  s = 'Read the docs at: https://openocl.org/api-docs/';
