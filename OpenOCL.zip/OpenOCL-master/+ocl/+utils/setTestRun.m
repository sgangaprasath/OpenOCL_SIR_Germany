function setTestRun(val)
global testRun
testRun = val;
