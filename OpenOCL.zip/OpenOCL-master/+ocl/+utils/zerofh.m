function r = zerofh()
r = @(varargin)0;