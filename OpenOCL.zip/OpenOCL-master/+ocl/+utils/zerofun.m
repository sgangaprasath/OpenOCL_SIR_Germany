function r = zerofun(varargin)
r = 0;