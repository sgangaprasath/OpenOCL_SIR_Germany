function r = emptyfh()
r = @(varargin)[];