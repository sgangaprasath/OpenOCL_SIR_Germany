# Folder for external libaries

CasADi will be downloaded to the `Workspace` folder and extracted to the `Lib/casadi` folder. 
Check the archive package file of CasADi in `Workspace` or the `Lib/casadi` folder for License information
regarding CasADi.